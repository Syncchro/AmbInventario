import java.util.Map;

import javax.naming.InitialContext;

import org.apache.catalina.loader.WebappLoader
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

createDatasource = {
	Map dsConfig = config?.ctrlusu?.development?.datasource
	if(dsConfig){
		SimpleNamingContextBuilder builder = SimpleNamingContextBuilder.emptyActivatedContextBuilder();
		for(conf in dsConfig.entrySet()){
			String entryName = conf.getKey();
			Map props = conf.getValue();
			
			def ds = new BasicDataSource();
			for(e in props.entrySet()){
				ds."$e.key" = e.value
			}
			builder.bind("java:comp/env/$entryName", ds)
		}
			builder.createInitialContextFactory(null).getInitialContext(null);
	}
}

deployWebapps = { tomcat ->
	Map webAppConfig = config?.ctrlusu?.development?.webapp
	if(webAppConfig){
		for(conf in webAppConfig){
			def props = conf.value
			def webContext = "/$conf.key"
			def warFile = new File(grailsSettings.baseDir, props.warFile)
			
			def libDir = null
			if(props.libDir){
				libDir = new File(grailsSettings.baseDir, props.libDir)
			}
			
			def resourcesDir = null
			if(props.resources){
				resourcesDir = new File(grailsSettings.baseDir, props.resources)
			}
			
			tomcat.enableNaming()
			def context = tomcat.addWebapp(webContext, warFile.absolutePath)
			
			
			def loader = new WebappLoader(new ClownClassloader(new URL[0], tomcat.class.classLoader))
			
			if(libDir){
				loader.addRepository(libDir.toURI().toURL().toString())
			}
			
			if(resourcesDir){
				loader.addRepository(resourcesDir.toURI().toURL().toString())
			}
			
			loader.container = context
			context.loader = loader
		}
	}
}

class ClownClassloader extends URLClassLoader{
	
		public ClownClassloader(URL[] url, ClassLoader parent){
			super(url, parent)
			
		}
	
		public Class loadClass(String clazz) throws ClassNotFoundException {
			if(clazz.contains("webflow")){
				return null;
			}
			
			return super.loadClass(clazz);
		}
	}
	

