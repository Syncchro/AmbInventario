import grails.util.BuildSettings

includeTargets << grailsScript("Init")
includeTargets << grailsScript('_GrailsBootstrap')

target(main: "Gera o arquivo modulos-data.xml incluindo todos os controllers presentes na aplicacao.") {
	depends checkVersion, configureProxy, bootstrap

	def BuildSettings bf = new BuildSettings();
	def target =  bf.getProjectTargetDir()

	def File f = new File('modulos-data.xml', target)
	if(f.exists()){
		if(!f.delete()){
			throw new RuntimeException("Nao foi possivel remover o arquivo existente.")
		}
	}
	f.createNewFile();
	
	
	def appName = grailsApp.getMetadata()['app.name']

	f.append("""<?xml version="1.0" encoding="ISO-8859-1"?>
	<ARVORE>
		<ROOT>
			<NOME>$appName</NOME>
			<DESCRICAO>$appName</DESCRICAO>
			
			<MODULOS>
				<MODULO>
					<NOME>Telas</NOME>
					<DESCRICAO>Telas</DESCRICAO>
					<MODULOS>
	""")
	
	for (c in grailsApp.getArtefacts("Controller")){
		def cName = c.logicalPropertyName
		def nName = c.naturalName
		f.append("""
				<MODULO page-id="$cName">
					<NOME>$nName</NOME>
					<DESCRICAO>$nName</DESCRICAO>
				</MODULO>
		""")
	}

	f.append('''
					</MODULOS>
				</MODULO>
			</MODULOS>
		</ROOT>
</ARVORE>
	''')
	
}

setDefaultTarget(main)
