target(main: "Empacota o CtrlUsu Java como WAR") {

	
	ant.zip(destFile: "target/resources.jar"){
		fileset(dir: "${basedir}/ctrlusu/resources")
	}
	
	ant.zip(destFile: "target/ctrlusu.war"){
		fileset(dir: "${basedir}/ctrlusu/war")
		zipfileset(file: "target/resources.jar", fullpath: "WEB-INF/lib/resources.jar")
	}
	
	ant.delete(file: "target/resources.jar")
}

setDefaultTarget(main)