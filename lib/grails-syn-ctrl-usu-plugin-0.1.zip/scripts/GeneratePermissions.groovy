import grails.util.BuildSettings;



includeTargets << grailsScript("Init")
includeTargets << grailsScript('_GrailsBootstrap')



target(main: "Generates a SQL Script that inserts permissions for all controllers") {
	depends checkVersion, configureProxy, bootstrap
	
	def BuildSettings bf = new BuildSettings();
	def target =  bf.getProjectTargetDir()
	
	def File f = new File('ctrl_usu_permissoes.sql', target)
	if(f.exists()){
		if(!f.delete()){
			throw new RuntimeException("Nao foi possivel remover o arquivo existente.")
		}
	}
	f.createNewFile();
	
	

	for (c in grailsApp.getArtefacts("Controller")){
		def cName = c.logicalPropertyName + ".Acessar"
		def nName = c.naturalName
		f.append("insert into t_sec_permissao(IDE_PERMISSAO, DES_PERMISSAO, NOM_PERMISSAO, OBJ_VERSION) values (SQ_PERMISSAO.nextval, '$nName', '$cName', 0);\n")
	}
	
	f.append("commit;\n")

}


setDefaultTarget(main)

