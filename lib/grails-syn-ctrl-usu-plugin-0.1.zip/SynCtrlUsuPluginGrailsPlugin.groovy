
class SynCtrlUsuPluginGrailsPlugin {
	// the plugin version
	def version = "0.1"
	// the version or versions of Grails the plugin is designed for
	def grailsVersion = "1.3.7 > *"
	// the other plugins this plugin depends on
	def dependsOn = ['jquery':'1.6.1.1 > *']
	// resources that are excluded from plugin packaging
	def pluginExcludes = [
		"grails-app/views/error.gsp",
		"grails-app/conf/SeleniumConfig.groovy",
		"scripts/_Events.groovy",
		"grails-app/views/carros/*",
		"grails-app/views/fabricante/*",
		"grails-app/views/modelos/*",
		"grails-app/views/layouts/*",
		"grails-app/views/vendedores/*",
		"grails-app/controllers/br/com/synchro/appref/*",
		"grails-app/domain/br/com/synchro/ctrlusu/appref/*",
	]
	

	def author = "SCC1"
	def authorEmail = "scc1@synchro.com.br"
	def title = "Synchro Controle de Usuarios"
	def description = '''\\
'''

	// URL to the plugin's documentation
	def documentation = "http://grails.org/plugin/syn-ctrl-usu-plugin"

	def doWithWebDescriptor = { xml ->
	}

	def doWithSpring = {
	}

	def doWithDynamicMethods = { ctx ->
	}

	def doWithApplicationContext = { applicationContext ->
	}

	def onChange = { event ->
		// TODO Implement code that is executed when any artefact that this plugin is
		// watching is modified and reloaded. The event contains: event.source,
		// event.application, event.manager, event.ctx, and event.plugin.
	}

	def onConfigChange = { event ->
		// TODO Implement code that is executed when the project configuration changes.
		// The event is the same as for 'onChange'.
	}
}
