package br.com.synchro.ctrlusu.plugin

class CtrlUsuIndisponivelException extends Exception{

}
