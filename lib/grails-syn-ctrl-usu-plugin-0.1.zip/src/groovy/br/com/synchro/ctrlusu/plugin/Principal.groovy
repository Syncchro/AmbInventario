package br.com.synchro.ctrlusu.plugin

class Principal {

	def nome
	def tipo
	
	
	boolean equals(other) {
		def ret = false;
		if(other instanceof  Principal){
			ret = nome.equals(other.nome) && tipo.equals(other.tipo)
		}
		
		return ret
	}
	
	int hashCode(){
		return nome.hashCode()
	}
}
