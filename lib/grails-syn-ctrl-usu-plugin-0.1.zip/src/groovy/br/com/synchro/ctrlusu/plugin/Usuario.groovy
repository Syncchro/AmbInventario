package br.com.synchro.ctrlusu.plugin

class Usuario {

	def nome
	def codigoLogin
	def email
	def password
	def codigoDominio
	def senhaExpirada
	def primeiroAcesso
	def principals = new HashSet()
	def admin
	
}
