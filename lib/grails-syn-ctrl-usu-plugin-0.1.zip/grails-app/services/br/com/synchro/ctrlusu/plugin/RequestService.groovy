package br.com.synchro.ctrlusu.plugin

import grails.converters.JSON

import org.apache.commons.io.IOUtils;
import org.codehaus.groovy.grails.commons.ConfigurationHolder

class RequestService {

	static transactional = false

	def static Boolean MODULOS_DATA_SEND_STATUS = false
	def static CTRL_USU_API_URL = ConfigurationHolder.config.ctrlusu.api.url

	def request (path, parameters){
		uploadModulosData()
		try {		
			if(!path.startsWith('/')){
				path = "/" + path
			}
			def apiUrl = new URL (CTRL_USU_API_URL + path)
			def conn = apiUrl.openConnection()
			conn.setRequestMethod("POST")
			conn.doOutput = true
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(parameters);
			writer.flush();
			conn.connect()
			return conn.content.getText("UTF-8")
		} catch (Exception e){
			MODULOS_DATA_SEND_STATUS = false
			throw e
		}
	}
	
	def uploadModulosData() {
		if (!MODULOS_DATA_SEND_STATUS) {
			MODULOS_DATA_SEND_STATUS = true
			def is = this.getClass().getClassLoader().getResourceAsStream("modulos-data.xml")
			if (is) {
				def result = request("/service/custom/modulos-data", IOUtils.toString(is))
				if (!"OK".equals(result)) {
					throw new RuntimeException("Erro desconhecido ao configurar o Modulos Data no Controle de Usuários");
				}
				print "MODULOS DATA CONFIGURADO"
			}
		}
	}
	
	def obterCondicoesNovaSenha(){
		def resp = request("service/user/condicoesNovaSenha", "")
		def parsed
		if(resp){
			 parsed = JSON.parse(resp)
		}
		return parsed.root.condicoes
	}
}
