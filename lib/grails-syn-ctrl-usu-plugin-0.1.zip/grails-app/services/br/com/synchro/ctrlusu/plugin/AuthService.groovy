package br.com.synchro.ctrlusu.plugin

import org.apache.commons.collections.CollectionUtils;
import org.codehaus.groovy.grails.commons.ConfigurationHolder;

class AuthService {

    static transactional = false
	def static blacklist

	static {
		if (!blacklist) {
			blacklist = ['login','organizacao','alterarSenha']
			def c = ConfigurationHolder.config.ctrlusu.filter.whitelist.controllers
			if (c) {
				def config = c.split("\\|")
				CollectionUtils.addAll(blacklist, config);
			}
		}
	}
	
	
    def boolean authController(String controller, principals) {
		def principal = new Principal(nome: controller + ".Acessar", tipo: 'br.com.cit.caf.security.auth.PermissionPrincipal')
		if (principals.contains(principal) || blacklist.contains(controller)) {
			return true;
		} else {
			return false;
		}
    }
}
