package br.com.synchro.ctrlusu.plugin

import org.apache.commons.io.IOUtils;
import org.springframework.web.context.request.RequestContextHolder;

import grails.converters.JSON

class SecurityService {

    static transactional = false
	
	def RequestService requestService

	def getUsuarioCorrente() {
		return RequestContextHolder.currentRequestAttributes().getSession()?.user
	}
	
	def alterarSenha(def username, def passwordAtual, def newPassword, def confirmacaoNewPassword){
		def resp = requestService.request("service/user/alterarSenha", "user=$username&pass=$passwordAtual&newPass=$newPassword&confirmNewPass=$confirmacaoNewPassword")
		
		if(resp){
			return  JSON.parse(resp)
		}
	}

}
