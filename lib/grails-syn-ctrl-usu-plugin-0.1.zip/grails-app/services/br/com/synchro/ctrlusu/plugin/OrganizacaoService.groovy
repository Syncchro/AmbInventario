package br.com.synchro.ctrlusu.plugin

import grails.converters.JSON;

class OrganizacaoService {

	def RequestService requestService
	static transactional = false

	def recuperarPrincipalUsuarioOrg(orgId, username) {
		def principals = new HashSet()
		def textSelecaoOrg
		try{
			textSelecaoOrg = requestService.request("service/login/selecionaOrgContexto/$username/$orgId", "")
		}catch(Exception e){
			throw new CtrlUsuIndisponivelException();
		}
		if(textSelecaoOrg){
			def auth = JSON.parse(textSelecaoOrg)
			for(p in auth.auth.principals){
				principals.add(new Principal(nome:p.nome, tipo:p.tipo))
			}
		}
		return principals
	}

	def listarOrgCadastraisUsuario(codigoUsu) {
		def organizacoes = []
		def text
		try{
			text = requestService.request("service/org/listarCadastrais/$codigoUsu", "")
		} catch(Exception e){
			throw new CtrlUsuIndisponivelException()
		}
		if(text){
			def orgs = JSON.parse(text)
			for(o in orgs){
				organizacoes.add(o.org);
			}
		}
		return organizacoes
	}
}
