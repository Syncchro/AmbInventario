package br.com.synchro.ctrlusu.plugin

import org.springframework.beans.factory.annotation.Required;

class CtrlUsuTagLib {

	static namespace = "ctrlusu"
	def AuthService authService
	def SecurityService securityService
	
	/**
	 * Aceita todos atributos da tag g:link
	 * 
	 * @attr controller REQUIRED nome do controller de destino do link
	 */
	def link = {attrs, body ->
		def controller = attrs.controller
		def Usuario user = securityService.getUsuarioCorrente()
		if (user && authService.authController(controller, user.principals)) {
			def modelMap = [:]
			modelMap.putAll(attrs)
			modelMap << ["text": body()]
			out << render(plugin: "syn-ctrl-usu-plugin", template: "/ctrlUsuTagLib/link", model: modelMap)
		}
	}
	
	/**
	 * @attr anyControllers lista contendo nomes dos controllers em que pelo um deles o usuario deve possuir permissao
	 * @attr allControllers lista contendo os nomes dos controllers em que o usuario deve possuir permissao.
	 */
	def autorizar = {attrs, body ->
		def anyControllers = attrs.anyControllers
		def allControllers = attrs.allControllers
		def Usuario user = securityService.getUsuarioCorrente()
		if (anyControllers && !allControllers) {
			for (def c : anyControllers) {
				if (authService.authController(c, user.principals)) {
					out << body()
					break;
				}
			}
		}
		if (allControllers && !anyControllers) {
			def renderizar = true
			for (def c : allControllers) {
				if (!authService.authController(c, user.principals)) {
					renderizar = false
					break;
				}
			}
			if (renderizar) {
				out << body()
			}
		}
	}
	
	def isAdmin = {attrs, body ->
		def Usuario user = securityService.getUsuarioCorrente()
		if (user.admin) {
			out << body()
		}
	}	
	
}
