package br.com.synchro.ctrlusu.plugin

import grails.converters.JSON

class OrganizacaoController {

	def RequestService requestService
	def OrganizacaoService organizacaoService
	def SecurityService securityService

	def listSelecaoOrg = {
		def codigoUsu = securityService.getUsuarioCorrente().codigoLogin
		try {
			def organizacoes = organizacaoService.listarOrgCadastraisUsuario(codigoUsu)

			def orgId = securityService.getUsuarioCorrente().codigoDominio
			//seleciona a primeira org da lista
			if(!securityService.getUsuarioCorrente().codigoDominio && !organizacoes.isEmpty()){
				orgId = organizacoes[0].codigoDominio
			}
			trocaOrgContexto(orgId)

			def list = securityService.getUsuarioCorrente().principals.groupBy({p -> p.tipo});
			def profilePrincipal = list['br.com.cit.caf.security.auth.ProfilePrincipal']

			return [orgs: organizacoes, profiles: profilePrincipal]

		}  catch (CtrlUsuIndisponivelException e) {
			redirect(uri: '/connectionError')
		}

	}

	def selecionaOrg = {
		trocaOrgContexto(params.orgsCadastrais)
		def list = securityService.getUsuarioCorrente().principals.groupBy({p -> p.tipo});
		def profilePrincipal = list['br.com.cit.caf.security.auth.ProfilePrincipal']
		redirect(uri: '/home')
	}

	def trocaOrgContexto = {orgId ->
		try {
			def principals = organizacaoService.recuperarPrincipalUsuarioOrg(orgId, securityService.getUsuarioCorrente().codigoLogin)
			securityService.getUsuarioCorrente().principals = principals
			securityService.getUsuarioCorrente().codigoDominio = orgId
		} catch (CtrlUsuIndisponivelException e) {
			redirect(uri: '/connectionError')
		}
	}
}
