package br.com.synchro.ctrlusu.plugin

import grails.converters.JSON

import javax.servlet.http.Cookie

class LoginController {

	def static condicoesNovaSenha
	def RequestService requestService
	def SecurityService securityService
	def OrganizacaoService organizacaoService

	def index = {
	}

	def denied ={
	}

	def logout = {
		session.invalidate();
		redirect(action:'index')
	}

	def ctrlUsu = {

		if(session.user){
			def userName = session.user.codigoLogin
			def password = session.user.password


			def sessionid
			try{
				sessionid = requestService.request("service/login/login/", "user=$userName&pass=$password")
			}catch(Exception e){
				redirect(uri:'/connectionError')
			}

			if(sessionid?.startsWith("ERRO:")){
				flash.message = sessionid;
				redirect(uri: '/home')
			}else{
				def contextPath = RequestService.CTRL_USU_API_URL.substring(RequestService.CTRL_USU_API_URL.lastIndexOf('/'), RequestService.CTRL_USU_API_URL.length())
				def cookie = new Cookie("JSESSIONID", sessionid);
				cookie.path = contextPath
				response.addCookie(cookie)
				redirect(url:RequestService.CTRL_USU_API_URL)
				if (session.admin) {
					session.invalidate();
				}
			}
		}else{
			redirect(controller: 'login')
		}
	}

	def alterarSenhaPrimeiroAcesso = {
		def parsed
		try{
			parsed = securityService.alterarSenha(params.codigoLogin, params.passwordAtual, params.newPassword, params.confirmacaoNewPassword)
		}catch(Exception e){
			flash.message = "Controle de Usuários indisponível no momento. Contate o administrador do sistema.";
			render(view:'index')
		}

		if(parsed){
			// possui mensagem de erro
			if(parsed.password.mensagem){
				flash.message = parsed.password.mensagem
				render(view:'primeiroAcesso', model:[conds: condicoesNovaSenha, primeiroAcesso:true])
				return
			}

			// verifico se existe um hash com a nova senha
			if (parsed.password.hash) {
				forward(action:'login', params:[pUser: params.codigoLogin, pPass: params.newPassword])
			} else {
				flash.message = "Erro desconhecido ao realizar primeiro acesso"
				render(view:'index')
			}
		}
	}

	def primeiroAcesso = {
		try{
			condicoesNovaSenha = requestService.obterCondicoesNovaSenha()
		}catch(Exception e){
			flash.message = "Controle de Usuários indisponível no momento. Contate o administrador do sistema.";
			render(view:'index')
		}

		return [conds: condicoesNovaSenha, primeiroAcesso:true, codigoLogin:params.pUser]
	}

	def login = {
		def resp
		try{
			resp = requestService.request("service/login/auth/", "user=$params.pUser&pass=$params.pPass")
		}catch(Exception e){
			flash.message = "Controle de Usuários indisponível no momento. Contate o administrador do sistema.";
			render(view:'index')
		}

		
		if(resp){
			def parsed = JSON.parse(resp)

			if(parsed.auth.primeiroAcesso){
				redirect(action:'primeiroAcesso', params:[codigoLogin:params.pUser])
				return
			}

			def message = parsed.auth.message
			def senhaExpirada = parsed.auth.senhaExpirada
			if(message){
				flash.message = message;
				if(senhaExpirada){
					redirect(action:'primeiroAcesso', params:[codigoLogin:params.pUser])
				}else{
					render(view:'index')
				}
			}else{
				def usuario = new Usuario();
				usuario.nome = parsed.auth.username
				usuario.password = parsed.auth.hash
				usuario.codigoLogin = parsed.auth.codigoLogin
				usuario.email = parsed.auth.email
				usuario.admin = parsed.auth.admin
				session.setAttribute("user", usuario);

				if (!parsed.auth.possuiOrgCadastral) {
					session.setAttribute("admin", true);
					redirect(action: 'ctrlUsu')
				} else {
					// selecionar uma org
					try {
						selecionaPrimeiraOrgContexto()
						redirect(uri:'/home')
					} catch (CtrlUsuIndisponivelException e) {
						session.setAttribute("user", null);
						redirect(uri: '/connectionError')
					}
				}
			}
		}
	}


	def selecionaPrimeiraOrgContexto() {
		// recuperar OrgCadastrais Usuario
		def organizacoes = organizacaoService.listarOrgCadastraisUsuario(session.user.codigoLogin)
		def orgId = organizacoes[0].codigoDominio
		def principals = organizacaoService.recuperarPrincipalUsuarioOrg(orgId, securityService.getUsuarioCorrente().codigoLogin)
		securityService.getUsuarioCorrente().principals = principals
		securityService.getUsuarioCorrente().codigoDominio = orgId
	}
}
