package br.com.synchro.ctrlusu.plugin

import grails.converters.JSON;

class AlterarSenhaController {

	def RequestService requestService
	def SecurityService securityService 
	
    def index = {
		def condicoesNovaSenha
		try{
			condicoesNovaSenha = requestService.obterCondicoesNovaSenha()
		}catch(Exception e){
			redirect(uri:'/connectionError')
		}

		[conds: condicoesNovaSenha]
	}
	
	def alterar = {
		def username =  session?.user?.codigoLogin
		def parsed
		try{
			parsed = securityService.alterarSenha(username, params.passwordAtual, params.newPassword, params.confirmacaoNewPassword)
		}catch(Exception e){
			flash.message = "Controle de Usuários indisponível no momento. Contate o administrador do sistema.";
			redirect(view: 'index')
		}

		if(parsed){
			// possui mensagem de erro
			if(parsed.password.mensagem){
				flash.message = parsed.password.mensagem
				redirect(view: 'index')
				return
			}
			
			// verifico se existe um hash com a nova senha
			if (parsed.password.hash) {
				session.user.password = parsed.password.hash
				flash.message = "Senha alterada com sucesso"
				redirect(view: 'index')
			} else {
				flash.message = "Erro desconhecido ao alterar a senha"
				redirect(view: 'index')
			}
		}			
	}
}
