import br.com.synchro.ctrlusu.plugin.AuthService;

import br.com.synchro.ctrlusu.plugin.SecurityService;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.ListUtils;
import org.apache.commons.lang.ArrayUtils;
import org.codehaus.groovy.grails.commons.ConfigurationHolder;

import br.com.synchro.ctrlusu.plugin.Principal

/**
 *
 * @author Paulo Freitas (PVF) - paulo.freitas@synchro.com.br
 *
 */
class CtrlUsuFilters {

	def AuthService authService	

	def filters = {
		authenticate(controller:'*', action:'*') {
			before = {
				if(!session.user && !'login'.equals(controllerName)){
					redirect(controller: 'login', action:'index')
					return false
				}
			}
		}

		authorize(controller:'*', action:'*') {
			before = {
				if(session.user){
					if (!controllerName) {
						return true;	
					}
					if (authService.authController(controllerName, session.user.principals)) {
						return true
					} else {
						redirect(controller: 'login', action:'denied')
						return false
					}
				}
			}
		}
	}
}
